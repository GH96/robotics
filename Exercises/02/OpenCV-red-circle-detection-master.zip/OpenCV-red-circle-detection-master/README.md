OpenCV red circles detection
=============================

Here you could find the code for **Detect red circles in an image using OpenCV**, for more informations visit the project webpage:

https://solarianprogrammer.com/2015/05/08/detect-red-circles-image-using-opencv/

Copyright 2015 Sol from www.solarianprogrammer.com
